# Contributing

All contributions are welcome. Just make a PR. Below is a list of general improvements that need to be added that I would love help with:

- Improve documentation
- Clean up code (by fixing pep8 errors)
- Better algorithms that reduce time complexity (espescially for course #3 & #4)
- ...
