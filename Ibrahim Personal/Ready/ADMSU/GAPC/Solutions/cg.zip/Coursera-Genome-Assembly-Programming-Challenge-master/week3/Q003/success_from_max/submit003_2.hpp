//
//  submit003_2.hpp
//  error_prone
//
//  Created by 陈贝茜 on 2018/6/30.
//  Copyright © 2018年 陈贝茜. All rights reserved.
//

#ifndef submit003_2_hpp
#define submit003_2_hpp

#include <stdio.h>

#endif /* submit003_2_hpp */
